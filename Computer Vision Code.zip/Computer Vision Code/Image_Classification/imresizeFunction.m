
imageFolder = fullfile(pwd,'images_rgb\Suspension\');

imds = dir(imageFolder);

numfiles = size(imds,1) ;

for i = 3:numfiles
    file = imread(strcat(imageFolder,imds(i).name));
    filename =strcat(imageFolder,imds(i).name);
imdsresize = imresize(file, [224,224]);
imwrite(imdsresize,filename);
end