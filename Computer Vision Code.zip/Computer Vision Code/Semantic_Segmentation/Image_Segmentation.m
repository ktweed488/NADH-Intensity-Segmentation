
outputFolder = fullfile(pwd);

imgDir = fullfile(outputFolder,'images_raw');
labelDir = fullfile(outputFolder,'labels_raw');
HelperFunctions.prepareData(imgDir,labelDir);

% Get the full path for the folder containing all the raw images
imgDir = fullfile(outputFolder,'images_raw');

% Load the images located in the above path using imageDatstore - ML Function
imds = imageDatastore(imgDir);


classes = [
    "Cell"    
    "Background"
    ];
labelIDs = HelperFunctions.camvidPixelLabelIDs();
% Create the full path to the directory that contains the ground truth pictures.
labelDir = fullfile(outputFolder,'labels_raw');

% This function works similarly to imageDatastore. Instead it returns a datastore object that can be used to read pixel label data. - Computer Vision System Toolbox
pxds = pixelLabelDatastore(labelDir,classes,labelIDs);

% Create a custom colormap to color each label in a different way
cmap = HelperFunctions.camvidColorMap;

%% Overlay segmentation results onto original image. - Computer Vision System Toolbox

tbl = countEachLabel(pxds)
% We calculate the frequency in order to get a histogram of the data
frequency = tbl.PixelCount/sum(tbl.PixelCount);

figure
bar(1:numel(classes),frequency)
xticks(1:numel(classes)) 
xticklabels(tbl.Name)
xtickangle(45)
ylabel('Frequency')

[imdsTrain, imdsVal, imdsTest, pxdsTrain, pxdsVal, pxdsTest] = HelperFunctions.partitionCamVidData(imds,pxds,labelIDs);

numTrainingImages = numel(imdsTrain.Files)
numTestingImages = numel(imdsTest.Files)
numValImages = numel(imdsVal.Files)

imageSize = [224 224 3];
numClasses = numel(classes);

% segnetLayers returns SegNet network layers, lgraph, that is preinitialized with layers and weidghts from a pretrained model.
lgraph = deeplabv3plusLayers(imageSize, numClasses, "resnet18");

%% Get the imageFreq using the data from the countEachLabel function
imageFreq = tbl.PixelCount ./ tbl.ImagePixelCount;

% The higher the frequency of a class the smaller the classWeight
classWeights = median(imageFreq) ./ imageFreq
pxLayer = pixelClassificationLayer('Name','labels','ClassNames', tbl.Name, 'ClassWeights', classWeights)


% Remove last layer of and add the new one we created. 
lgraph = replaceLayer(lgraph,"classification",pxLayer);

pximdsVal = pixelLabelImageDatastore(imdsVal,pxdsVal);

%% Define training options. 
options = trainingOptions('sgdm', ...
    'LearnRateSchedule','piecewise',...
    'LearnRateDropPeriod',10,...
    'LearnRateDropFactor',0.3,...
    'Momentum',0.9, ...
    'InitialLearnRate',1e-3, ...
    'L2Regularization',0.005, ...
    'ValidationData',pximdsVal,...
    'MaxEpochs',10, ...  
    'MiniBatchSize',1, ...
    'Shuffle','every-epoch', ...
    'CheckpointPath', tempdir, ...
    'VerboseFrequency',2,...
    'Plots','training-progress',...
    'ValidationPatience', 4);


augmenter = imageDataAugmenter('RandXReflection',true,...
    'RandXTranslation', [-10 10], 'RandYTranslation',[-10 10]);

pximds = pixelLabelImageDatastore(imdsTrain,pxdsTrain, ...
    'DataAugmentation',augmenter);

%% Trains a network for image classification problems
tic
[net, info] = trainNetwork(pximds,lgraph,options);
toc
save('SegmenterCNN.mat','net','info','options');
disp('NN trained');

pic_num = 30;
I = readimage(imds, pic_num);
Ib = readimage(pxds, pic_num);

IB = labeloverlay(I, Ib, 'Colormap', cmap, 'Transparency',0.8);

%% Show the results of the semantic segmentation
C = semanticseg(I, net);
CB = labeloverlay(I, C, 'Colormap', cmap, 'Transparency',0.8);
figure
imshowpair(IB,CB,'montage')
HelperFunctions.pixelLabelColorbar(cmap, classes);
title('Ground Truth vs Predicted')


I = read(imdsTest);

C = semanticseg(I, net);
B = labeloverlay(I, C, 'Colormap', cmap, 'Transparency',0.8);
figure
imshow(B)
HelperFunctions.pixelLabelColorbar(cmap, classes);
expectedResult = read(pxdsTest);

expected = uint8(expectedResult{1});
predicted = uint8(C);

%% Compare differences between images - Image Processing toolbox
imshowpair(expected, predicted, 'montage')
title('Ground Truth labels vs Predicted labels')

%% Jaccard similarity coefficient for image segmentation - Image Processing Toolbox
iou = jaccard(C, expectedResult{1});

table(classes,iou)

outputFold = fullfile(pwd, 'Results');

pxdsResults = semanticseg(imdsTest,net, ...
    'MiniBatchSize',4, ...
    'WriteLocation',outputFold, ...
    'Verbose',false);

metrics = evaluateSemanticSegmentation(pxdsResults,pxdsTest,'Verbose',false);
metrics.DataSetMetrics
metrics.ClassMetrics






