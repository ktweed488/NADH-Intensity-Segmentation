%% Load images

inputFolder = fullfile(pwd);

imgDir = fullfile(inputFolder,'images_test_results');
outputDir = fullfile(inputFolder,'images_test_results_objects');
imds = imageDatastore(imgDir);

reset(imds);
while hasdata(imds)
    % Read an image.
    [I,info] = read(imds);
    I = im2double(I);
    % Resize image.
    D = bwdist(~I);
    D = -D;
    L = watershed(D);
    L(~I) = 0;
    
    % Write to disk.
    [~, filename, ext] = fileparts(info.Filename);
    imwrite(L, fullfile(outputDir, [filename  ext]))
end






