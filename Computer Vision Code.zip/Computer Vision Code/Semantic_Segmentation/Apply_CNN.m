
%% load CNN and images to apply it to

load('SegmenterCNN.mat')

inputFolder = fullfile(pwd);

imgDir = fullfile(inputFolder,'images_test');
outputDir = fullfile(inputFolder,'images_test_proc');
imds = imageDatastore(imgDir);

%resize data to work with CNN
reset(imds)
while hasdata(imds)
    % Read an image.
    [I,info] = read(imds);
    
    % Resize image.
    I = imresize(I,[224 224]);
    % Write to disk.
    [~, filename, ext] = fileparts(info.Filename);
    imwrite(I, fullfile(outputDir, [filename  ext]))
end

imds = imageDatastore(outputDir);

%% Apply CNN to resized images
outputFold = fullfile(pwd, 'images_test_results');

pxdsResults = semanticseg(imds,net, ...
    'MiniBatchSize',4, ...
    'WriteLocation',outputFold, ...
    'Verbose',false);
%2 is background, 1 is cells
imdsProc = imageDatastore(outputFold);

reset(imdsProc)

while hasdata(imdsProc)
    % Read an image.
    [I,info] = read(imdsProc);
    
    % Resize image.
    I = imresize(I,[256 256]);
    I(I==2) = 0;
    I(I==1) = 255;
    
    % Write to disk.
    [~, filename, ext] = fileparts(info.Filename);
    imwrite(I, fullfile(outputFold, [filename  ext]))
end








