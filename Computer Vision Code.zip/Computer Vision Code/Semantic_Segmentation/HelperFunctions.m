classdef HelperFunctions < handle
    
    properties
    end
    
    methods(Static)
        
        function pixelLabelColorbar(cmap, classNames)
            % Add a colorbar to the current axis. The colorbar is formatted
            % to display the class names with the color.
            
            colormap(gca,cmap)
            
            % Add colorbar to current figure.
            c = colorbar('peer', gca);
            
            % Use class names for tick marks.
            c.TickLabels = classNames;
            numClasses = size(cmap,1);
            
            % Center tick labels.
            c.Ticks = 1/(numClasses*2):1/numClasses:1;
            
            % Remove tick mark.
            c.TickLength = 0;
        end
        
        function cmap = camvidColorMap()
            % Define the colormap used by CamVid dataset.
            
            cmap = [
                000 000 000     % Background
                255 255 255     % Cell
                ];
            
            % Normalize between [0 1].
            cmap = cmap ./ 255;
        end
        
        function labelIDs = camvidPixelLabelIDs()
            % Return the label IDs corresponding to each class.
            %
            % The CamVid dataset has 32 classes. Group them into 10 classes following
            % the a similar SegNet training methodology [3].
            %
            % The 10 classes are:
            %   "Environment" "Building", "Pole", "Road", "Pavement", "SignSymbol",
            %   "Car", "Pedestrian",  and "Bicyclist".
            %
            % CamVid pixel label IDs are provided as RGB color values. Group them into
            % 11 classes and return as a cell array of M-by-3 matrices. The original
            % CamVid class names are listed alongside each RGB value.
            labelIDs = { ...
                
            
            % "Background"
            [
            000 000 000; ... % "Background"
            ]
            
            % "Cell"
            [
            255 255 255; ... % "Cell"
            ]
            
            };
        end
        
        % This is to prepare the data in the beginning
        function prepareData(imageFolder, labelFolder)
            imds = imageDatastore(imageFolder);
            pxds = imageDatastore(labelFolder);
            
            HelperFunctions.resizeCamVidImages(imds, imageFolder);
            HelperFunctions.resizeCamVidLabelImages(pxds, labelFolder);
        end       

        function [imds, pxds] = resizeDataset(imds,imageFolder, pxds, labelFolder)
            % This takes 79 seconds
            imds = HelperFunctions.resizeCamVidImages(imds,imageFolder);
            % This takes 24 seconds
            pxds = HelperFunctions.resizeCamVidPixelLabels(pxds,labelFolder);
        end
            
        function imds = resizeCamVidImages(imds, imageFolder)
            % Resize images to [360 480].
            
            if ~exist(imageFolder,'dir')
                mkdir(imageFolder)
            else
                imds = imageDatastore(imageFolder);
                checkSize = read(imds);
                if size(checkSize) == [224 224 3]
                    disp('Image data already resized')
                    return; % Skip if images already resized
                
                end
            end
            
            reset(imds)
            while hasdata(imds)
                % Read an image.
                [I,info] = read(imds);
                
                % Resize image.
                I = imresize(I,[224 224]);
                % Write to disk.
                [~, filename, ext] = fileparts(info.Filename);
                imwrite(I, fullfile(imageFolder, [filename  ext]))
            end
            
            imds = imageDatastore(imageFolder);
        end
        
        function pxds = resizeCamVidLabelImages(pxds, labelFolder)
            % Resize pixel label data to [360 480].
            
            if ~exist(labelFolder,'dir')
                mkdir(labelFolder)
            else
                pxds = imageDatastore(labelFolder);
                checkSize = read(pxds);
                if (size(checkSize,1) == 224) && (size(checkSize,2) == 224)
                    disp('Label data already resized')
                    return; % Skip if images already resized
                end
            end
            
            reset(pxds)
            while hasdata(pxds)
                % Read the pixel data.
                [C,info] = read(pxds);
                
                % Resize the data. Use 'nearest' interpolation to
                % preserver label IDs.
                C = imresize(C,[224 224],'nearest');
                
                % Write the data to disk.
                [~, filename, ext] = fileparts(info.Filename);
                imwrite(C,fullfile(labelFolder, [filename ext]))
            end
        end
        
        function pxds = resizeCamVidPixelLabels(pxds, labelFolder)
            % Resize pixel label data to [360 480].
            
            classes = pxds.ClassNames;
            labelIDs = 1:numel(classes);
            if ~exist(labelFolder,'dir')
                mkdir(labelFolder)
            else
                pxds = pixelLabelDatastore(labelFolder,classes,labelIDs);
                checkSize = imread(pxds.Files{1});
                if (size(checkSize,1) == 224) && (size(checkSize,2) == 224)
                    disp('Label data already resized')
                    return; % Skip if images already resized
                end
            end
            
            reset(pxds)
            while hasdata(pxds)
                % Read the pixel data.
                [C,info] = read(pxds);
                
                % Convert from categorical to uint8.
                L = uint8(C);
                
                % Resize the data. Use 'nearest' interpolation to
                % preserver label IDs.
                L = imresize(L,[224 224],'nearest');
                
                % Write the data to disk.
                [~, filename, ext] = fileparts(info.Filename);
                imwrite(L,fullfile(labelFolder, [filename ext]))
            end
            
            labelIDs = 1:numel(classes);
            pxds = pixelLabelDatastore(labelFolder,classes,labelIDs);
        end

        
        function [imdsTrain, imdsVal,imdsTest, pxdsTrain, pxdsVal, pxdsTest] = partitionCamVidData(imds,pxds,labelIDs)
            % Partition CamVid data by randomly selecting 60% of the data for training. The
            % rest is used for testing.
            
            % Set initial random state for example reproducibility.
            rng(0);
            numFiles = numel(imds.Files);
            % Returns a row vector containing a random permutation of the integers from 1 to n inclusive.
            shuffledIndices = randperm(numFiles);
            
            % Use 60% of the images for training.
            N = round(0.60 * numFiles);
            trainingIdx = shuffledIndices(1:N);
            
            % Use the rest for testing.
            int = shuffledIndices(N+1:end);
            testIdx = int(1:end/2);
            valIdx = int(end/2:end);
            
            % Create image datastores for training and test.
            trainingImages = imds.Files(trainingIdx);
            testImages = imds.Files(testIdx);
            valImages = imds.Files(valIdx);
            imdsTrain = imageDatastore(trainingImages);
            imdsTest = imageDatastore(testImages);
            imdsVal = imageDatastore(valImages);
            
            % Extract class and label IDs info
            classes = pxds.ClassNames;
%             labelIDs = 1:numel(pxds.ClassNames);
            
            % Create pixel label datastores for training and test.
            trainingLabels = pxds.Files(trainingIdx);
            testLabels = pxds.Files(testIdx);
            valLabels = pxds.Files(valIdx);
            pxdsTrain = pixelLabelDatastore(trainingLabels, classes, labelIDs);
            pxdsTest = pixelLabelDatastore(testLabels, classes, labelIDs);
            pxdsVal = pixelLabelDatastore(valLabels, classes, labelIDs);
        end
        
        function showImageMapping(pxds,cmap)
            
            C_rgb = imread(pxds.Files{30});
            C = readimage(pxds, 30);
            
            if size(C_rgb,1) == 720
                B = labeloverlay(C_rgb(600:650,600:650,:),C(600:650,600:650,:),'ColorMap',cmap);
                % Show a ground-truth array
                C(600:650,600:650)
            else
                B = labeloverlay(C_rgb(300:325,300:325,:),C(300:325,300:325,:),'ColorMap',cmap);
                C(300:325,300:325)
            end
            reset(pxds);
            imshow(B,'InitialMagnification',200)
            
        end
        
        function showRotationEffect(imds,pxds,pic_num,degrees)
            
            I = readimage(imds, pic_num);
            Ib = readimage(pxds, pic_num);
            
            cmap = HelperFunctions.camvidColorMap();
            
            IIB = labeloverlay(I, Ib, 'Colormap', cmap, 'Transparency',0.8);
            
            % Convert from categorical to uint8.
            L = uint8(Ib);
            
            Ir = imrotate(I,degrees,'nearest','crop');
            Lr = imrotate(L,degrees,'nearest','crop');
            
            valueset = 1:10;
            
            LB = categorical(Lr, valueset,pxds.ClassNames);
            IB = labeloverlay(Ir, LB, 'Colormap', cmap, 'Transparency',0.8);
            
            figure
            imshowpair(IIB,IB,'montage');
            HelperFunctions.pixelLabelColorbar(cmap, pxds.ClassNames);
            title('Original vs Rotated image')
        end
        
    end
    
    
    
end
